# SimpleDmp
Librería para lectura de valores DMP de IMU MPU6050
